import './assets/worker.ts-C1Fa9D46.js';
