// src/activate.ts
document.dispatchEvent(new CustomEvent("OpenFTRTools", { detail: {} }));
